#ifndef __DISTANCE_H__
#define __DISTANCE_H__

#include "Area.h"
#include "BingoEnum.h"

class Distance
{
    public:
        Distance(Area *area);
        void initcost();
        void initturncost();
        bool checkRoute(int pt[]);
        void calcDistance();
        void setStart(int node);
        int calcTurncost(int goal[], DIR dir);
        void calcTurncostAll(DIR start_dir);
        int getLenAndTurnCost(int node);
        DIR getGoalDirection(int goal);

        void debugPrint();
        void debugPrint2();


    private:
        Area *mArea;
		double initialcost[7][7] = 
                            {{100,100,100,100,100,100,100}, 
							 {100,100,100,100,100,100,100} , 
							 {100,100,100,100,100,100,100} , 
							 {100,100,100,100,100,100,100} , 
							 {100,100,100,100,100,100,100} , 
							 {100,100,100,100,100,100,100} , 
							 {100,100,100,100,100,100,100} };
        double resultcost[7][7];
        double turncost[7][7];

        int st[2];

};

#endif

