#ifndef __RUNNER_H__
#define __RUNNER_H__
#include "BlockPlace.h"
#include "BingoEnum.h"
#include "Block.h"

class Runner
{
    public:
        Runner();
        void setStart(BlockPlace *bp);
        void setEnd(BlockPlace *bp);
        BlockPlace *getStart();
        BlockPlace *getEnd();


        void setDir(DIR dir);
        void carryBlock(Block *bk);
        Block *checkBlock();
        void releaseBlock();
        int turnRunner(int turn);
        int checkDirection(int from_[],int to[]);
        DIR getDir();
        Runner *makeClone();

    private:
        DIR dir;

        BlockPlace *start;
        BlockPlace *end;

        Block *block;
};


#endif