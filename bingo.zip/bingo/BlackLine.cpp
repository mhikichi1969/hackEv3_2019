#include "BlackLine.h"

BlackLine::BlackLine(int node):
    BlockPlace(node)
{
    kind=BPKIND::LINE;

}