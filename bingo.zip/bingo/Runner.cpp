#include "Runner.h"
#include "math.h"

Runner::Runner():
    dir(DIR::W),
    start(nullptr),
    end(nullptr),
    block(nullptr)
{

}

void Runner::setStart(BlockPlace *bp)
{
    start = bp;
}
void Runner::setEnd(BlockPlace *bp)
{
    end = bp;
}
BlockPlace* Runner::getStart()
{
    return start; 
}
BlockPlace* Runner::getEnd()
{
    return end;
}

void Runner::setDir(DIR d)
{
    dir = d;
}

void Runner::carryBlock(Block *bk)
{
    block = bk;
}

Block* Runner::checkBlock()
{
    return block;
}

void Runner::releaseBlock()
{
    block = nullptr;
}

// turn : 右方向+  左方向-
int Runner::turnRunner(int turn) {
    int dir_num = (int)dir;
    dir_num = dir_num+turn;
    if (dir_num>3) dir_num=dir_num-4;
    if (dir_num<0) dir_num=dir_num+4;
    dir = (DIR)dir_num;
    return (int)fabs(turn);
}

/* 座標から回転方向を算出　*/		
int Runner::checkDirection(int from_[],int to[]) {
        int ret=0;
		if (dir==DIR::N) {
			if (from_[1]>to[1])
				ret = turnRunner(-1);
			else if(from_[1]<to[1])
				ret = turnRunner(1);
			else if (from_[0]<to[0])
				ret = turnRunner(2);
        }
		if (dir==DIR::E) {
			if (from_[0]>to[0])
				ret = turnRunner(-1);
			else if (from_[0]<to[0])
				ret = turnRunner(1);
			else if (from_[1]>to[1])
				ret = turnRunner(2);
        }
		if (dir==DIR::S) {
			if (from_[1]>to[1])
				ret = turnRunner(1);
			else if(from_[1]<to[1])
				ret = turnRunner(-1);
			else if (from_[0]>to[0])
				ret = turnRunner(2);
        }
		if (dir==DIR::W) {
			if (from_[0]>to[0])
				ret = turnRunner(1);
			else if (from_[0]<to[0])
				ret = turnRunner(-1);
			else if (from_[1]<to[1])
				ret = turnRunner(2);
        }
		return ret;
}

DIR Runner::getDir()
{
    return dir;
}

Runner *Runner::makeClone()
{
    Runner *clone= new Runner();
    clone->dir = dir;

    clone->start=start;
    clone->end=end;

    clone->block = block;

    return clone;
}
