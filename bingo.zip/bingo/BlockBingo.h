#ifndef __BLOCK_BINGO_H__
#define __BLOCK_BINGO_H__

#include "Area.h"
#include "Distance.h"
#include "Runner.h"

class BlockBingo
{
    public:
        BlockBingo();
        void selectCarry();


    private:
        Area *mArea;
        Distance *mDistance;
        Runner *mRunner;



};


#endif
