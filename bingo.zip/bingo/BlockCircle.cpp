#include "BlockCircle.h"

BlockCircle::BlockCircle(int node,int id,int col)
        :BlockPlace(node),
        circleid(id),
        color(col)
{
    kind=BPKIND::BLOCK;

}