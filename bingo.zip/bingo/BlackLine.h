#ifndef __BLACK_LINE_H__
#define __BLACK_LINE_H__

#include "BlockPlace.h"

class BlackLine : public BlockPlace
{
    public:
        BlackLine(int node);


    private:
    
};


#endif