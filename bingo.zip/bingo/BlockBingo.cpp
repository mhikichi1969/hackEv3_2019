#include "BlockBingo.h"
#include "util.h"
#include "BlockPlace.h"
#include "BingoEnum.h"
#include "Block.h"

BlockBingo::BlockBingo()
{
    mArea = new Area();
    mDistance  = new Distance(mArea);
    mRunner = mArea->getRunner();
}

void BlockBingo::selectCarry()
{
    int node[20];
    mArea->getBlockList(node);

    BlockPlace *start = mRunner->getStart();
    
    int maxcost=0;
    int cost,cost2;

    int node_idx=3;

    int st = start->getNodeid();
    mRunner->setStart(mArea->getBlockPlace(node[node_idx]));
    mDistance->setStart(st);
    Block *tmp = mArea->getBlock(node[node_idx]);
    mDistance->calcDistance();
    mDistance->calcTurncostAll(DIR::W);
    cost = mDistance->getLenAndTurnCost(node[node_idx]);    
    //mDistance->debugPrint2();
    mArea->setBlock(node[node_idx],tmp);

    // 運搬先読み
    BlockPlace *bp = mArea->getBlockPlace(node[node_idx]);
    mRunner->setStart(bp);
    Block *bk = bp->getBlock();
    mRunner->carryBlock(bk);
    COLOR col = bk->getColor();
    
    DIR runner_dir = mDistance->getGoalDirection(node[node_idx]);
    mRunner->setDir(runner_dir);
    mDistance->setStart(node[node_idx]);
    mDistance->calcDistance();
    mDistance->calcTurncostAll(runner_dir);
    mDistance->debugPrint2();

    cost2 = mDistance->getLenAndTurnCost(node[node_idx]);    


    char buf[256];
    //sprintf(buf,"%d %d %d %d %d %d ",(int)runner_dir );
    //msg_f(buf,0);

   /* char buf[256];
    sprintf(buf,"%d %d %d %d %d %d ",node[0],node[1],node[2],node[3],node[4],node[5] );
    msg_f(buf,0);*/


}
