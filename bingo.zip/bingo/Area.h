#ifndef __AREA_H__
#define __AREA_H__

#include "BlockPlace.h"
#include "Block.h"
#include "Runner.h"

class Area
{
    public:
         Area();
        BlockPlace *getBlockPlace(int idx);
        void getBlockList(int node[]);
        Runner* getRunner();
        Block* getBlock(int id);
        void setBlock(int id,Block *bk);

    private:
        BlockPlace *bp[49];
        Runner *runner;


};

#endif