#include "CarryBlock.h"

CarryBlock::CarryBlock(Area *area):
        mArea(area)
{
    

}

