#include "Block.h"


Block::Block(COLOR col)
{
    color = col;

}

COLOR Block::getColor()
{
    return color;
}