#include "Distance.h"
#include "Runner.h"
#include "math.h"

#include "util.h"

Distance::Distance(Area *area):
    mArea(area)
{

		
}

void Distance::initcost()
{
    for(int i=0;i<7;i++) {
        for(int j=0;j<7;j++) {
            resultcost[i][j]=initialcost[i][j];
        }
    }
}

void Distance::initturncost()
{
    for(int i=0;i<7;i++) {
        for(int j=0;j<7;j++) {
            turncost[i][j]=initialcost[i][j];
        }
    }
}


void Distance::setStart(int node)
{
    st[0] = node/7; //row
    st[1] = node%7; //col
}

/* 進入不可チェック
 pt は座標(row,col)
*/
bool Distance::checkRoute(int pt[])
{
    int idx = pt[0]*7+pt[1];
    if(mArea->getBlockPlace(idx)==nullptr) 
        return false;
    if(mArea->getBlockPlace(idx)->getKind()==BPKIND::BLOCK)
        return false;
    if (mArea->getBlockPlace(idx)->getBlock()!=nullptr)
        return false;
    return true;
}

void Distance::calcDistance() {
    initcost();
    resultcost[st[0]][st[1]]=0;
    
    int change=true;
    while (change) {
        change = false;
        for (int row=0;row<7;row++){
            for (int col=0;col<7;col++) {
                int n[] = {row-1, col};
                int e[] = {row,col+1 };
                int s[] = {row+1,col };
                int w[] = {row,col-1 };
                
                if (n[0]>=0){
                    if (checkRoute(n) ) {
                        if (resultcost[n[0]][n[1]] > resultcost[row][col]+1) {
                            resultcost[n[0]][n[1]] = resultcost[row][col]+1;
                            change=true;
                        }
                    }
                }
                if (e[1]<=6){
                    if (checkRoute(e)) {
                        if (resultcost[e[0]][e[1]] > resultcost[row][col]+1){
                            resultcost[e[0]][e[1]] = resultcost[row][col]+1;
                            change=true;
                        }
                    }
                }
                if (s[0]<=6){
                    if (checkRoute(s)){
                        if (resultcost[s[0]][s[1]] > resultcost[row][col]+1){
                            resultcost[s[0]][s[1]] = resultcost[row][col]+1;
                            change=true;
                        }
                    }
                }
                if (w[1]>=0){
                    if (checkRoute(w)){
                        if (resultcost[w[0]][w[1]] > resultcost[row][col]+1) {
                            resultcost[w[0]][w[1]] = resultcost[row][col]+1;
                            change=true;	
                        }
                    }
                }
            }
        }
    }                   
}

int Distance::calcTurncost(int goal[], DIR dir){
    int start_dir = ((int)dir+2)%4;
    int cost;

    int row = goal[0];
    int col = goal[1];	
    if (resultcost[row][col]==100)
        return 100;
    if (resultcost[row][col]==0)
        return 0;

    int no = resultcost[row][col];

    Runner *runner=mArea->getRunner();

    cost = 0;
    int cnt=0;
    int newcost;
    while (no!=0) { 
        int n[] = {row-1, col};
        int e[] = {row,col+1};
        int s[] = {row+1,col};
        int w[] = {row,col-1};
        if (0<=n[0] && n[0]<=6 && 0<=n[1] && n[1]<=6 && resultcost[n[0]][n[1]]==resultcost[row][col]-1) {
            no = resultcost[n[0]][n[1]];
            int pt[] = {row,col};
            newcost = runner->checkDirection(pt,n);
            if (cnt!=0) cost = cost +newcost;
            row = n[0];
            col = n[1];
        } else if(0<=e[0] && e[0]<=6 && 0<=e[1] && e[1]<=6  && resultcost[e[0]][e[1]]==resultcost[row][col]-1) {
            no = resultcost[e[0]][e[1]];
            int pt[] = {row,col};
            newcost = runner->checkDirection(pt,e);
            if (cnt!=0) cost = cost +newcost;
            row = e[0];
            col = e[1];
        } else if( 0<=s[0] && s[0]<=6 && 0<=s[1] && s[1]<=6 && resultcost[s[0]][s[1]]==resultcost[row][col]-1) {
            no = resultcost[s[0]][s[1]];
            int pt[] = {row,col};
            newcost = runner->checkDirection(pt,s);
            if (cnt!=0) cost = cost +newcost;
            row = s[0];
            col = s[1];
        } else if(0<=w[0] && w[0]<=6 && 0<=w[1] && w[1]<=6  && resultcost[w[0]][w[1]]==resultcost[row][col]-1) {
            no = resultcost[w[0]][w[1]];
            int pt[] = {row,col};
            newcost = runner->checkDirection(pt,w);
            if (cnt!=0) cost = cost +newcost;
            row = w[0];
            col = w[1];
        } else {
            return 100;
        }
        cnt++;
    }
    cost = cost+fabs((int)runner->getDir()-start_dir);
    return cost;		
}		
void Distance::calcTurncostAll(DIR start_dir) {
        initturncost();
		for (int row =0; row<7;row++) 
		    for (int col =0; col<7;col++) {
                int pt[] = {row,col};
        		turncost[row][col] = calcTurncost(pt,start_dir);
            }
		//debugPrint2();
}

int Distance::getLenAndTurnCost(int node)
{
    int pt[]={node/7,node%7};
    return resultcost[pt[0]][pt[1]]+turncost[pt[0]][pt[1]];
}

/* コスト表から走行体の進入方法を推定*/
DIR Distance::getGoalDirection(int goal){
    int row = goal/7;
    int col = goal%7;	

    int n[] = {row-1, col};
    int e[] = {row,col+1};
    int s[] = {row+1,col};
    int w[] = {row,col-1};
    int min=100;
    DIR result=(DIR)-1;
    if (0<=n[0] && n[0]<=6 && 0<=n[1] && n[1]<=6 && resultcost[n[0]][n[1]]+turncost[n[0]][n[1]]<min) {
        min = resultcost[n[0]][n[1]]+turncost[n[0]][n[1]];
        result = DIR::S;
    }
    if ( 0<=e[0] && e[0]<=6 && 0<=e[1] && e[1]<=6 && resultcost[e[0]][e[1]]+turncost[e[0]][e[1]]<min) {
        min = resultcost[e[0]][e[1]]+turncost[e[0]][e[1]];
        result = DIR::W;
    }
    if  (0<=s[0] && s[0]<=6 && 0<=s[1] && s[1]<=6 && resultcost[s[0]][s[1]]+turncost[s[0]][s[1]]<min) {
        min = resultcost[s[0]][s[1]]+turncost[s[0]][s[1]];
        result = DIR::N;
    }
    if  (0<=w[0] && w[0]<=6 && 0<=w[1] && w[1]<=6 && resultcost[w[0]][w[1]]+turncost[w[0]][w[1]]<min) {
        min = resultcost[w[0]][w[1]]+turncost[w[0]][w[1]];
        result = DIR::E;
    }

    return result;
}




void Distance::debugPrint()
{
    char buf[256];
    char tmp[8];
    int line=2;
    for(int j=0;j<7;j++,line++) {
        for(int i=0;i<7;i++) {
            if(resultcost[j][i]>=10) 
                tmp[i] = '*';
            else 
                tmp[i] = '0'+resultcost[j][i];
        }
        sprintf(buf,"%c %c %c %c %c %c %c",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5],tmp[6]  );
        msg_f(buf,line);
    }

}

void Distance::debugPrint2()
{
    char buf[256];
    char tmp[8];
    int line=2;
    for(int j=0;j<7;j++,line++) {
        for(int i=0;i<7;i++) {
            if(turncost[j][i]>=10) 
                tmp[i] = '*';
            else 
                tmp[i] = '0'+turncost[j][i];
        }
        sprintf(buf,"%c %c %c %c %c %c %c",tmp[0],tmp[1],tmp[2],tmp[3],tmp[4],tmp[5],tmp[6]  );
        msg_f(buf,line);
    }

}

