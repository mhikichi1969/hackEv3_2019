#ifndef __CROSS_CIRCLE_H__
#define __CROSS_CIRCLE_H__

#include "BlockPlace.h"

class CrossCircle : public BlockPlace
{
    public:
        CrossCircle(int node,int id, int color);


    private:
        int circleid;
        int color;
    
};


#endif