#ifndef __BLOCK_CIRCLE_H__
#define __BLOCK_CIRCLE_H__

#include "BlockPlace.h"

class BlockCircle : public BlockPlace
{
    public:
        BlockCircle(int node,int id, int color);


    private:
        int circleid;
        int color;

       
    
};


#endif