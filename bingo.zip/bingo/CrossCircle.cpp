#include "CrossCircle.h"

CrossCircle::CrossCircle(int node,int id,int col)
        :BlockPlace(node),
        circleid(id),
        color(col)
{
    kind=BPKIND::CROSS;

}